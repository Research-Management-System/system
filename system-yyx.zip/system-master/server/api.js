// 可能是我的node版本问题，不用严格模式使用ES6语法会报错
"use strict";
const models = require('./db');
const express = require('express');
const router = express.Router();

//查询登录状态
router.get('/api/isLogin',(req,res) => {
  let account = req.session.account;
  if(account){
    models.Login.findOne({account:account},(err,data) => {
      let allData = {
        userInfo: data
      };
      if(allData.userInfo.type === 1){
        //考虑使用promise重写,处理回调地狱
        models.Project.find({students:account},(err,projects) => {
          allData.projects = projects;
          models.Projectapply.find({account:account},(err,projectApply) => {
            allData.projectApply = projectApply;
            // models.ProjectG.find({students:account},(err,projectGs) =>{
            //    allData.projectGs = projectGs;
            //  });
            models.Sthesis.find({apply:account},(err,sthesises) => {
              allData.sthesises = sthesises;
              models.Gthesis.find({apply:account},(err,gthesises) => {
                allData.gthesises = gthesises;
                models.Patent.find({apply:account},(err,patents) => {
                  allData.patents = patents;
                  models.Assets.find({user:account},(err,assets) => {
                    allData.assets = assets;
                    models.Render.find({apply:account},(err,renders) => {
                      allData.renders = renders;
                      res.send(allData);
                    });
                  });
                });
              })
            });
          });
        });
      }else{
        models.Project.find((err,projects) => {
          allData.projects = projects;
          models.Projectapply.find({teacher:account},(err,projectApply) => {
            allData.projectApply = projectApply;
            models.ProjectG.find((err,projectGs) =>{
              allData.projectGs = projectGs;
              models.Sthesis.find((err,sthesises) => {
                allData.sthesises = sthesises;
                models.Gthesis.find((err,gthesises) => {
                  allData.gthesises = gthesises;
                  models.Patent.find((err,patents) => {
                    allData.patents = patents;
                    models.Assets.find((err,assets) => {
                      allData.assets = assets;
                      models.Render.find((err,renders) => {
                        allData.renders = renders;
                        models.Login.find({teacher:account,state:0},(err,signInApply) => {
                          allData.signInApply = signInApply;
                          res.send(allData);
                        });
                      });
                    });
                  });
                });
              });
            });
          });
        });
      }
    });
  }else{
    res.send(account);
  }
});
//注销接口
router.get('/api/logoff',(req,res) => {
  req.session.account = null;
  res.send("log off success!");
});
/*
// 登录接口
router.post('/api/login',(req,res) => {
    // 通过模型去查找数据库
    let account = req.body.account;
    let password = req.body.password;
    models.Login.findOne({account:account},(err,data) => {
        if (!data) {
            let msg = "0";
            res.send(msg);
        } else if(data.password != password){
            let msg = "1";
            res.send(msg);
        } else {
            req.session.account = account;
            let allData = {
              userInfo: data
            };
            if(allData.userInfo.type === 1){
              models.Project.find({students:account},(err,projects) => {
                allData.projects = projects;
                models.Projectapply.find({account:account},(err,projectApply) => {
                  allData.projectApply = projectApply;
                  // models.ProjectG.find({students:account},(err,projectGs) =>{
                  //    allData.projectGs = projectGs;
                  //  });
                  models.Sthesis.find({apply:account},(err,sthesises) => {
                    allData.sthesises = sthesises;
                    models.Gthesis.find({apply:account},(err,gthesises) => {
                      allData.gthesises = gthesises;
                      models.Patent.find({apply:account},(err,patents) => {
                        allData.patents = patents;
                        models.Assets.find({user:account},(err,assets) => {
                          allData.assets = assets;
                          models.Render.find({apply:account},(err,renders) => {
                            allData.renders = renders;
                            res.send(allData);
                          });
                        });
                      });
                    })
                  });
                });
              });
            }else{
              models.Project.find((err,projects) => {
                allData.projects = projects;
                models.Projectapply.find({teacher:account},(err,projectApply) => {
                  allData.projectApply = projectApply;
                  models.ProjectG.find((err,projectGs) =>{
                    allData.projectGs = projectGs;
                    models.Sthesis.find((err,sthesises) => {
                      allData.sthesises = sthesises;
                      models.Gthesis.find((err,gthesises) => {
                        allData.gthesises = gthesises;
                        models.Patent.find((err,patents) => {
                          allData.patents = patents;
                          models.Assets.find((err,assets) => {
                            allData.assets = assets;
                            models.Render.find((err,renders) => {
                              allData.renders = renders;
                              models.Login.find({teacher:account,state:0},(err,signInApply) => {
                                allData.signInApply = signInApply;
                                res.send(allData);
                              });
                            });
                          });
                        });
                      });
                    });
                  });
                });
              });
            }
        }
    });
});*/
//修改密码
router.post('/api/changePassword',(req,res) => {
  console.log(req.body.newPassword);
	console.log(req.body.oldPassword);
  let account = req.body.account;
  let password = req.body.newPassword;
	let prepassword = req.body.oldPassword;

  models.Login.update({$and:[{'account':account},{'password':prepassword}]},{$set:{'password':req.body.newPassword}},function(err){
    if(err){
      console.log(err);
      let msg = "0";
      res.send(msg);
    }else{
      let msg = "1";
      res.send(msg);
    }
  });
});
//用户注册
router.post('/api/signIn',(req,res) => {
	let account = req.body.account;
	let password = req.body.password;
	let name = req.body.name;
	let email = req.body.email;
	let phone = req.body.phone;
	let type = req.body.type;
	let teacher = req.body.teacher;
  let state = 1;
  if(type===1){
    state = 0;
  }
	var user = {
		type : type,
		name : name,
		account : account,
		password : password,
		email : email,
		phone : phone,
		state : state,
		teacher : teacher,
		projects : new Array(),
		time : new Date()
	}
	models.Login.findOne({'account':account},function(err,data){
		if(err){
			console.log("err");
		}else{
			if(data===null){
				models.Login.create(user,function(err){
					if(err){
						let msg = "0";
						res.send(msg);
						console.log("注册失败");
					}else{
						res.send("1");
						console.log("注册成功");
					}
				});
			}else{
				let msg = "0";
				res.send(msg);
				console.log("不可重复注册");
			}
		}
	});
});
//修改用户信息
router.post('/api/changeUserinfo',(req,res) => {
  let account = req.body.account;
  let name = req.body.name;
  let email = req.body.email;
  let phone = req.body.phone;
  console.log(account+"用户修改信息");

  models.Login.update({'account':account},{$set:{'name':name,'email':email,'phone':phone}},function(err){
    if(err){
      console.log(err);
      res.send("0");
    }else{
      res.send("1");
    }
  });
});
//激活用户
router.post('/api/activeUser',(req,res) => {
  let account = req.body.account;
  models.Login.update({'account':account},{$set:{'state':1}},(err) => {
    if(err){
      console.log(err);
      res.send("0");
    }else{
      console.log("激活："+account);
      res.send("1");
    }
  });
});
//审核项目加入申请
router.post('/api/checkJoinProject',(req,res) => {
  let account = req.body.account;
  let projectId = req.body.id;
  let state = req.body.state;
  models.Projectapply.update({$and:[{'account':account},{'projectId':projectId}]},{$set:{'state':state}},(err) => {
    if(err){
      console.log(err);
      res.send("0");
    }else{
      if(state===1){
        console.log("同意申请"+account);
        models.Login.update({'account':account},{$addToSet:{'projects':projectId}},(err) => {
          models.Project.update({'id':projectId},{$addToSet:{'students':account}},(err) => {
            models.ProjectG.update({'projects':projectId},{$addToSet:{'students':account}},(err) => {
              models.Projectapply.update({state: 1},(err) =>{
                res.send("1");
              });
            });
          });
        });
      }else{
        models.Projectapply.update({state: 1},(err) =>{
          res.send("2");
        });
      }
    }
  });
});
//学生加入项目申请
router.post('/api/joinProject',(req,res) => {
  let account = req.body.account;
  let projectId = req.body.id;
  console.log(typeof(projectId));
  let state = 0;
  models.Projectapply.findOne({$and:[{'account':account},{'projectId':projectId}]},(err,apply) =>{
    if(apply){
      console.log("已申请，不可重复申请");
      res.send("0");
    }else{
      models.Project.findOne({'id':projectId},(err,data) => {
        if(data){
          var projectapply = {
            account : account,
            projectId : projectId,
            teacher : data.teacher,
            state : 0,
            time : new Date()
          }
          models.Projectapply.create(projectapply, function(err) {
            if(err){
              console.log(err);
              res.send("0");
            }
            else{
              console.log("成功申请"+account);
              res.send("1");
            }
          });
        }else{
          console.log("没有此项目");
          res.send("0");
        }
      });
    }
  });
});
//新建项目组
router.post('/api/createProjectGroup',(req,res) => {
  let name = req.body.name;
  let caption = req.body.caption;
  models.ProjectG.count((err,count) => {
    var id = (new Date().getFullYear())+"01"+(Array(5).join('0')+count).slice(-5);
    var projectG = {
      name : name,
      id : id,
      caption : caption,
      projects : new Array(),
      teachers : new Array(),
      students : new Array(),
      time : new Date()
    };
    models.ProjectG.create(projectG,(err) => {
      if(err){
        console.log("创建失败");
        res.send("0");
      }else{
        console.log("新建项目组"+id);
        res.send("1");
      }
    });
  });
});
//新建项目
router.post('/api/createProject',(req,res) => {
  let name = req.body.name;
  let teacher = req.body.teacher;
  let group = req.body.group;
  let account = req.body.account;
  let description = req.body.description;
  let id = req.body.id;
  //let id = "201702000001";//如果没传id可以用这个暂时测试
  //查询是否有这个id的项目了
  models.Project.findOne({'id':id},(err,data) => {
    if(data){
      console.log("该项目已经存在");
      res.send("0");
    }else{
      var project = {
        name : name,
        teacher : teacher,
        students : new Array(),
        id : id,
        group : group,
        account : account,
        description : description,
        time : new Date()
      };
      models.Project.create(project,(err) => {
        models.ProjectG.update({'id':group},{$addToSet:{'projects':id,'teachers':teacher}},(err) => {
          models.Login.update({'account':teacher},{$addToSet:{'projects':id}},(err) => {
            res.send("1");
          });
        });
      });
    }
  });
});

//学生向老师提交购买申请(固定资产入库)
router.post('/api/assetApply',(req,res)=>{
  let band = req.body.band;
  let name = req.body.name;
  let model =req.body.model;
  let cost = req.body.cost;
  let projectId = req.body.projectId;
  let teacher = req.body.teacher;
  let user = req.session.account;
  // router.post('/api/login',(req,res) => {
  // let band ="海尔空调";
  // let name = "海尔集团";
  // let model ="立式空调";
  // let cost = 2999;
  // let projectId = "20171302001";
  // let teacher = "568842";
  // let user ="13020031154";
  models.Assets.count((err,count) => {
    count=count+1;
    var id = (new Date().getFullYear())+"03"+(Array(5).join('0')+count).slice(-5); //id:年份+“03”+“固定资产购买申请数+1”，固定11位
    var asset={
      id :id,
      deviceId : "",//设备号
      band : band,//设备名
      name : name,//设备厂商
      model : model,//型号
      purchaseDate : null,//购买时间
      cost : cost,//价格
      projectId : projectId,//项目号
      account : "",//账号
      devicestate : 1,//设备状态1：正常 2：待修 3：报废
      user : user,//使用人，就是报账的这个用户????????????????????????????????????????????????????????????????
      ticket : "",//报账票据集合为一个pdf文件后上传
      state : 1,//申请审批状态
      teacher : teacher,//负责申购申请审批的老师
      time :new Date()//该条目生成时间
    }
    models.Assets.create(asset,function(err){
      if(err){
        res.send("0");
      }else{
        res.send("1");
      }
    });
  });
});

//老师审核购买申请(固定资产入库)
router.post('/api/checkAssetApply',(req,res)=>{
  let id = req.body.id;
  let state = req.body.state;
// router.post('/api/login',(req,res) => {
//   let id = "6947503750190";
//   let state = 0;
//   let state = 2;
  if(state === 0){ //不同意
    models.Assets.update({'id':id},{'$set':{'state':0}},function (err) {
      if(err){
        res.send("0");
      }else {
        res.send("1");
      }
    });
  }else {
    if(state === 2){ //同意
      models.Assets.update({'id':id},{'$set':{'state':2}},function (err) {
        if(err){
          res.send("0");
        }else {
          res.send("1");
        }
      });
    }
  }
})

//修改设备状态(固定资产入库)
router.post('/api/changeState',(req,res)=>{
  let id = req.body.id;
  let devicestate = req.body.devicestate;
//   router.post('/api/login',(req,res) => {
//   let id = "6947503750190";
   // let devicestate = 1;
  // let devicestate = 2;
  // let devicestate = 3;
  if(devicestate === 1){ //1:设备正常
    models.Assets.update({'id':id},{'$set':{'devicestate':1}},function (err) {
      if(err){
        res.send("0");
      }else {
        res.send("1");
      }
    });
  }else if(devicestate === 2){ //2：待修
    models.Assets.update({'id':id},{'$set':{'devicestate':2}},function (err) {
      if(err){
        res.send("0");
      }else {
        res.send("1");
      }
    });
  }else if(devicestate === 3) {//3：报废
    models.Assets.update({'id':id},{'$set':{'devicestate':3}},function (err) {
      if(err){
        res.send("0");
      }else {
        res.send("1");
      }
    });
  }
});

//提交报账申请(不入库报账)
router.post('/api/renderApply',(req,res)=>{
  let kind = req.body.kind;
  let description = req.body.description;
  let cost = req.body.cost;
  let projectId = req.body.projectId;
  let apply = req.session.account;
//   router.post('/api/login',(req,res) => {
//   let kind = "餐饮费";
//   let description = "中午吃肯德基花费59元";
//   let cost = 59;
//   let projectId = "20171302001";
//   let apply ="13020031154";
  models.Render.count((err,count) => {
    count=count+1;
    var id = (new Date().getFullYear())+"04"+(Array(5).join('0')+count).slice(-5); //id:年份+“04”+“报账申请数+1”
    var render ={
      id : id,
      kind : kind,
      description : description,
      account : "",
      apply : apply,//?????????????????????????????????????
      cost : cost,
      state : 1,
      ticket : "",//报账票据集合成一个pdf文件后上传
      time : new Date()
    }
    models.Render.create(render,function (err) {
      if(err){
        res.send("0");
      }else {
        res.send("1");
      }
    });
  });
});

//老师审核报账申请（不入库报账）
router.post('/api/checkRenderApply',(req,res)=>{
  let id = req.body.id;
  let state = req.body.state;
// router.post('/api/login',(req,res) => {
  // let id = "20170000001";
  // let state = 0;
  // let state = 2;
  if(state === 0){ //不同意
    models.Render.update({'id':id},{'$set':{'state':0}},function (err) {
      if(err){
        res.send("0");
      }else {
        res.send("1");
      }
    });
  }else {
    if(state === 2){ //同意
      models.Render.update({'id':id},{'$set':{'state':2}},function (err) {
        if(err){
          res.send("0");
        }else {
          res.send("1");
        }
      });
    }
  }
});

module.exports = router;
