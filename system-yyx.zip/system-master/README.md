# research-management-system

> My graduation project use Vue2.0+Express+MongoDB

## 启动
``` bash
# 进入对应目录
cd 目录
# install dependencies//下载依赖,需要提前安装node,第一次可能需要较长时间。
npm install

# serve with hot reload at localhost:8080 //启动项目,localhost:8080
npm run dev

# 启动服务器 http服务器，数据库是mongoDB,需要自行下载。数据库名字及模型在server/db.js中查看。
cd server
node index
```

